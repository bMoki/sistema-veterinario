package model;

public enum Pagamento {
    CARTAO_DEBITO,
    CARTAO_CREDITO,
    DINHEIRO,
    PIX,
    BOLETO
}
