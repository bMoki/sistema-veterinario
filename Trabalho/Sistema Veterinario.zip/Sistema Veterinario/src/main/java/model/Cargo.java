package model;

public enum Cargo {
    ADESTRADOR, ATENDENTE, AUXILIAR_VETERINARIO
}
